﻿namespace WindowsFormsApp1
{
    partial class frmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnInstanciarHorista = new System.Windows.Forms.Button();
            this.lbDataEntradaEmpresa = new System.Windows.Forms.Label();
            this.lbSalarioMensal = new System.Windows.Forms.Label();
            this.lbNome = new System.Windows.Forms.Label();
            this.lbMatricula = new System.Windows.Forms.Label();
            this.txtSalarioHoras = new System.Windows.Forms.TextBox();
            this.txtNomeEmpregrado = new System.Windows.Forms.TextBox();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtNumeroHoras = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtDiasFalta = new System.Windows.Forms.TextBox();
            this.txtDataEntradaEmpresa = new System.Windows.Forms.MaskedTextBox();
            this.SuspendLayout();
            // 
            // btnInstanciarHorista
            // 
            this.btnInstanciarHorista.Location = new System.Drawing.Point(295, 379);
            this.btnInstanciarHorista.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnInstanciarHorista.Name = "btnInstanciarHorista";
            this.btnInstanciarHorista.Size = new System.Drawing.Size(367, 261);
            this.btnInstanciarHorista.TabIndex = 19;
            this.btnInstanciarHorista.Text = "Instanciar Horista";
            this.btnInstanciarHorista.UseVisualStyleBackColor = true;
            this.btnInstanciarHorista.Click += new System.EventHandler(this.btnInstanciarHorista_Click);
            // 
            // lbDataEntradaEmpresa
            // 
            this.lbDataEntradaEmpresa.AutoSize = true;
            this.lbDataEntradaEmpresa.Location = new System.Drawing.Point(152, 206);
            this.lbDataEntradaEmpresa.Name = "lbDataEntradaEmpresa";
            this.lbDataEntradaEmpresa.Size = new System.Drawing.Size(195, 20);
            this.lbDataEntradaEmpresa.TabIndex = 18;
            this.lbDataEntradaEmpresa.Text = "Data Entrada na Empresa";
            // 
            // lbSalarioMensal
            // 
            this.lbSalarioMensal.AutoSize = true;
            this.lbSalarioMensal.Location = new System.Drawing.Point(152, 145);
            this.lbSalarioMensal.Name = "lbSalarioMensal";
            this.lbSalarioMensal.Size = new System.Drawing.Size(121, 20);
            this.lbSalarioMensal.TabIndex = 17;
            this.lbSalarioMensal.Text = "Salario por hora";
            // 
            // lbNome
            // 
            this.lbNome.AutoSize = true;
            this.lbNome.Location = new System.Drawing.Point(152, 89);
            this.lbNome.Name = "lbNome";
            this.lbNome.Size = new System.Drawing.Size(51, 20);
            this.lbNome.TabIndex = 16;
            this.lbNome.Text = "Nome";
            // 
            // lbMatricula
            // 
            this.lbMatricula.AutoSize = true;
            this.lbMatricula.Location = new System.Drawing.Point(152, 32);
            this.lbMatricula.Name = "lbMatricula";
            this.lbMatricula.Size = new System.Drawing.Size(73, 20);
            this.lbMatricula.TabIndex = 15;
            this.lbMatricula.Text = "Matricula";
            // 
            // txtSalarioHoras
            // 
            this.txtSalarioHoras.Location = new System.Drawing.Point(393, 141);
            this.txtSalarioHoras.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtSalarioHoras.Name = "txtSalarioHoras";
            this.txtSalarioHoras.Size = new System.Drawing.Size(198, 26);
            this.txtSalarioHoras.TabIndex = 13;
            // 
            // txtNomeEmpregrado
            // 
            this.txtNomeEmpregrado.Location = new System.Drawing.Point(393, 85);
            this.txtNomeEmpregrado.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtNomeEmpregrado.Name = "txtNomeEmpregrado";
            this.txtNomeEmpregrado.Size = new System.Drawing.Size(380, 26);
            this.txtNomeEmpregrado.TabIndex = 12;
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(393, 29);
            this.txtMatricula.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(112, 26);
            this.txtMatricula.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(152, 269);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(134, 20);
            this.label1.TabIndex = 21;
            this.label1.Text = "Numero de Horas";
            // 
            // txtNumeroHoras
            // 
            this.txtNumeroHoras.Location = new System.Drawing.Point(393, 265);
            this.txtNumeroHoras.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtNumeroHoras.Name = "txtNumeroHoras";
            this.txtNumeroHoras.Size = new System.Drawing.Size(198, 26);
            this.txtNumeroHoras.TabIndex = 20;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(152, 322);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 20);
            this.label2.TabIndex = 23;
            this.label2.Text = "Dias de falta";
            // 
            // txtDiasFalta
            // 
            this.txtDiasFalta.Location = new System.Drawing.Point(393, 319);
            this.txtDiasFalta.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtDiasFalta.Name = "txtDiasFalta";
            this.txtDiasFalta.Size = new System.Drawing.Size(198, 26);
            this.txtDiasFalta.TabIndex = 22;
            // 
            // txtDataEntradaEmpresa
            // 
            this.txtDataEntradaEmpresa.Location = new System.Drawing.Point(405, 200);
            this.txtDataEntradaEmpresa.Mask = "00/00/0000";
            this.txtDataEntradaEmpresa.Name = "txtDataEntradaEmpresa";
            this.txtDataEntradaEmpresa.Size = new System.Drawing.Size(100, 26);
            this.txtDataEntradaEmpresa.TabIndex = 24;
            this.txtDataEntradaEmpresa.ValidatingType = typeof(System.DateTime);
            this.txtDataEntradaEmpresa.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.txtDataEntradaEmpresa_MaskInputRejected);
            // 
            // frmHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1034, 745);
            this.Controls.Add(this.txtDataEntradaEmpresa);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtDiasFalta);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtNumeroHoras);
            this.Controls.Add(this.btnInstanciarHorista);
            this.Controls.Add(this.lbDataEntradaEmpresa);
            this.Controls.Add(this.lbSalarioMensal);
            this.Controls.Add(this.lbNome);
            this.Controls.Add(this.lbMatricula);
            this.Controls.Add(this.txtSalarioHoras);
            this.Controls.Add(this.txtNomeEmpregrado);
            this.Controls.Add(this.txtMatricula);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "frmHorista";
            this.Text = "frmHorista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnInstanciarHorista;
        private System.Windows.Forms.Label lbDataEntradaEmpresa;
        private System.Windows.Forms.Label lbSalarioMensal;
        private System.Windows.Forms.Label lbNome;
        private System.Windows.Forms.Label lbMatricula;
        private System.Windows.Forms.TextBox txtSalarioHoras;
        private System.Windows.Forms.TextBox txtNomeEmpregrado;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtNumeroHoras;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtDiasFalta;
        private System.Windows.Forms.MaskedTextBox txtDataEntradaEmpresa;
    }
}
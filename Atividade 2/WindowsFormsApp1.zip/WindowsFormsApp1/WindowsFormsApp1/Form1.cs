﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnMensalista_Click(object sender, EventArgs e)
        {
            frmMensalista frm = new frmMensalista();

            frm.Show();
        }

        private void btnHorista_Click(object sender, EventArgs e)
        {
            frmHorista frm = new frmHorista();

            frm.Show();
        }
    }
}

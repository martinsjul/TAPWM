﻿namespace WindowsFormsApp1
{
    partial class frmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtSalarioMensal = new System.Windows.Forms.TextBox();
            this.lbMatricula = new System.Windows.Forms.Label();
            this.lbNome = new System.Windows.Forms.Label();
            this.lbSalarioMensal = new System.Windows.Forms.Label();
            this.lbDataEntradaEmpresa = new System.Windows.Forms.Label();
            this.btnInstanciarMensalista = new System.Windows.Forms.Button();
            this.btnInstanciarMensalistaParametro = new System.Windows.Forms.Button();
            this.txtDataEntradaEmpresa = new System.Windows.Forms.MaskedTextBox();
            this.SuspendLayout();
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(410, 72);
            this.txtMatricula.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(112, 26);
            this.txtMatricula.TabIndex = 0;
            this.txtMatricula.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(410, 129);
            this.txtNome.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(380, 26);
            this.txtNome.TabIndex = 1;
            this.txtNome.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // txtSalarioMensal
            // 
            this.txtSalarioMensal.Location = new System.Drawing.Point(410, 185);
            this.txtSalarioMensal.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtSalarioMensal.Name = "txtSalarioMensal";
            this.txtSalarioMensal.Size = new System.Drawing.Size(198, 26);
            this.txtSalarioMensal.TabIndex = 2;
            this.txtSalarioMensal.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // lbMatricula
            // 
            this.lbMatricula.AutoSize = true;
            this.lbMatricula.Location = new System.Drawing.Point(169, 76);
            this.lbMatricula.Name = "lbMatricula";
            this.lbMatricula.Size = new System.Drawing.Size(73, 20);
            this.lbMatricula.TabIndex = 4;
            this.lbMatricula.Text = "Matricula";
            // 
            // lbNome
            // 
            this.lbNome.AutoSize = true;
            this.lbNome.Location = new System.Drawing.Point(169, 132);
            this.lbNome.Name = "lbNome";
            this.lbNome.Size = new System.Drawing.Size(51, 20);
            this.lbNome.TabIndex = 5;
            this.lbNome.Text = "Nome";
            // 
            // lbSalarioMensal
            // 
            this.lbSalarioMensal.AutoSize = true;
            this.lbSalarioMensal.Location = new System.Drawing.Point(169, 189);
            this.lbSalarioMensal.Name = "lbSalarioMensal";
            this.lbSalarioMensal.Size = new System.Drawing.Size(113, 20);
            this.lbSalarioMensal.TabIndex = 6;
            this.lbSalarioMensal.Text = "Salario Mensal";
            this.lbSalarioMensal.Click += new System.EventHandler(this.label3_Click);
            // 
            // lbDataEntradaEmpresa
            // 
            this.lbDataEntradaEmpresa.AutoSize = true;
            this.lbDataEntradaEmpresa.Location = new System.Drawing.Point(169, 250);
            this.lbDataEntradaEmpresa.Name = "lbDataEntradaEmpresa";
            this.lbDataEntradaEmpresa.Size = new System.Drawing.Size(195, 20);
            this.lbDataEntradaEmpresa.TabIndex = 7;
            this.lbDataEntradaEmpresa.Text = "Data Entrada na Empresa";
            // 
            // btnInstanciarMensalista
            // 
            this.btnInstanciarMensalista.Location = new System.Drawing.Point(61, 499);
            this.btnInstanciarMensalista.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnInstanciarMensalista.Name = "btnInstanciarMensalista";
            this.btnInstanciarMensalista.Size = new System.Drawing.Size(367, 261);
            this.btnInstanciarMensalista.TabIndex = 9;
            this.btnInstanciarMensalista.Text = "Instanciar Mensalista";
            this.btnInstanciarMensalista.UseVisualStyleBackColor = true;
            this.btnInstanciarMensalista.Click += new System.EventHandler(this.btnInstanciarMensalista_Click);
            // 
            // btnInstanciarMensalistaParametro
            // 
            this.btnInstanciarMensalistaParametro.Location = new System.Drawing.Point(609, 499);
            this.btnInstanciarMensalistaParametro.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnInstanciarMensalistaParametro.Name = "btnInstanciarMensalistaParametro";
            this.btnInstanciarMensalistaParametro.Size = new System.Drawing.Size(397, 261);
            this.btnInstanciarMensalistaParametro.TabIndex = 10;
            this.btnInstanciarMensalistaParametro.Text = "Instanciar mensalista passando parametros";
            this.btnInstanciarMensalistaParametro.UseVisualStyleBackColor = true;
            this.btnInstanciarMensalistaParametro.Click += new System.EventHandler(this.btnInstanciarMensalistaParametro_Click);
            // 
            // txtDataEntradaEmpresa
            // 
            this.txtDataEntradaEmpresa.Location = new System.Drawing.Point(410, 250);
            this.txtDataEntradaEmpresa.Mask = "00/00/0000";
            this.txtDataEntradaEmpresa.Name = "txtDataEntradaEmpresa";
            this.txtDataEntradaEmpresa.Size = new System.Drawing.Size(207, 26);
            this.txtDataEntradaEmpresa.TabIndex = 11;
            this.txtDataEntradaEmpresa.ValidatingType = typeof(System.DateTime);
            // 
            // frmMensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1040, 804);
            this.Controls.Add(this.txtDataEntradaEmpresa);
            this.Controls.Add(this.btnInstanciarMensalistaParametro);
            this.Controls.Add(this.btnInstanciarMensalista);
            this.Controls.Add(this.lbDataEntradaEmpresa);
            this.Controls.Add(this.lbSalarioMensal);
            this.Controls.Add(this.lbNome);
            this.Controls.Add(this.lbMatricula);
            this.Controls.Add(this.txtSalarioMensal);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMatricula);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "frmMensalista";
            this.Text = "frmMensalista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtSalarioMensal;
        private System.Windows.Forms.Label lbMatricula;
        private System.Windows.Forms.Label lbNome;
        private System.Windows.Forms.Label lbSalarioMensal;
        private System.Windows.Forms.Label lbDataEntradaEmpresa;
        private System.Windows.Forms.Button btnInstanciarMensalista;
        private System.Windows.Forms.Button btnInstanciarMensalistaParametro;
        private System.Windows.Forms.MaskedTextBox txtDataEntradaEmpresa;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TAPAula;

namespace WindowsFormsApp1
{
    public partial class frmHorista : Form
    {
        public frmHorista()
        {
            InitializeComponent();
        }

        private void btnInstanciarHorista_Click(object sender, EventArgs e)
        {
            Horista objHorista = new Horista();

            objHorista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objHorista.NomeEmpregado = txtNomeEmpregrado.Text;
            objHorista.SalarioHora = Convert.ToDouble(txtSalarioHoras.Text);
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(txtDataEntradaEmpresa.Text);
            objHorista.NumeroHora = Convert.ToDouble(txtNumeroHoras.Text);
            objHorista.DiasFalta = Convert.ToInt32(txtDiasFalta.Text);


            MessageBox.Show("Nome = " + objHorista.NomeEmpregado +
                "\n Matricula = " + objHorista.Matricula +
                "\n Tempo Trabalho = " + objHorista.TempoTrabalho() +
                "\n Salario Final = " + objHorista.SalarioBruto().ToString("N2"));
        }

        private void txtDataEntradaEmpresa_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }
    }
}
